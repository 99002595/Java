package com.lts.autowired;

public interface Shape {
	void calculateArea(int x,int y);

}
